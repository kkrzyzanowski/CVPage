export class Card{
    isActive = false;
    isHidden = false;
    card = null;
    textElement = null;
    previousStyleState = null;
    OnClick(activate){
        isActive = activate;
        isHidden = !this.isActive;
    }

    OnDefaut()
    {
        this.isActive = false;
        this.isHidden = false;
    }

    async StartCardAnimation()
    {
        if(this.isHidden)
        {
            this.card.classList.add("hoverCard");
            this.card.classList.remove("show");
            void this.card.offsetWidth;
            this.card.classList.add("hidden");

            await this.waitForActiveCard();

            this.card.classList.add("inactive");
        }
        else if(this.isActive && !this.isHidden)
        {
            $(this.textElement).off('animationend');
            this.card.classList.add("active");
            this.card.classList.add("hoverCard");
            this.card.classList.remove("maximize");
            void this.card.offsetWidth;
            this.card.classList.add("minimize");
            setTimeout(() => {
                this.textElement.classList.add("minimizeText");
            }, 500); 
            await new Promise(resolve => {
            $(this.textElement).on('animationend', () => {
                this.textElement.classList.remove("minimizeText");
                this.textElement.style.transform = "translate(-50%, -50%) scale(0.2) rotate(-90deg)";
                this.resolveHiddenCard();
            });
        });
        }
    }

    StartDefaultAnimation()
    {
        if(this.isActive && !this.hidden)
        {   
            this.card.classList.remove("minimize");
            void this.card.offsetWidth;
            this.card.classList.add("maximize");
            this.textElement.classList.remove("minimizeText");
            this.textElement.style.transform = "translate(-50%, -50%) scale(0.2) rotate(-90deg)"
            void this.textElement.offsetWidth;
            setTimeout(() => {
                this.textElement.classList.add("maximizeText");
            }, 1000); 
            $(this.textElement).off('animationend');
            $(this.textElement).on('animationend', () => {
                
                this.textElement.classList.remove("maximizeText");
                this.textElement.style.transform = "translate(0, 0) scale(1) rotate(-90deg)"
                this.card.classList.remove("hoverCard");
            });
            setTimeout(() => {
                this.card.classList.remove("active");
            }, 1000)
            this.isActive = false;
        }
        else if(!this.hidden)
        {
            setTimeout(() => {
                this.card.classList.remove("inactive");
            }, 1000);
            this.card.classList.remove("hoverCard");
            this.card.classList.remove("hidden");
            void this.card.offsetWidth;
            this.card.classList.add("show");
        }
    }

    waitForActiveCard() {
        return new Promise(resolve => {
            document.addEventListener("activeCardDone", resolve, {once: true});
        });
    }
    resolveHiddenCard(){
        document.dispatchEvent(new Event("activeCardDone"));
    }

    constructor(id)
    {
        this.card = document.getElementById(id);
        this.textElement = this.card.firstElementChild;
    }
}