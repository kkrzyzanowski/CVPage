export function contentLoader(fileIndex){
    let file = "";
    switch(fileIndex){
        case 3:
            file = "../about-me.html"
            break;
    }
    fetch(file)
        .then(response => response.text())
        .then(data => {
            document.getElementById("content").innerHTML = data;
        })
        .catch(error => console.error("Failed to load page", error));
}

export function contentDeloader(){
    document.getElementById("content").innerHTML = "";
}