import { contentDeloader, contentLoader } from "./contentLoader.js";
import { Card } from "./card.js";

let isContentRunned = false;
let cards = [];
let elementsCount = 0;
let menu = null;
let content = null;

export function runAnimation($event){
    isContentRunned = !isContentRunned;
    for(var i = 0; i<elementsCount;i++)
    {
        var card = cards.find(x => x.card.id == i);
        if(card)
        {   
            card.isActive = $event == i ? true : false;
            card.isHidden = $event != i ? true : false;
        }
    }
    var hideCards = cards.filter(x => { 
        if(x.isHidden == true)
            return x});
    var activeCard = cards.filter(x => {
        if(x.isActive == true)
            return x;
        });
    if(isContentRunned)
    {
        hideCards.forEach(x => x.StartCardAnimation());
        setTimeout(() => activeCard[0].StartCardAnimation(), 1500);
        runContent(i);
    }
    else
    {
        hideContent();
        //activeCard[0].StartDefaultAnimation();
        //setTimeout(() => hideCards.forEach(x => x.StartDefaultAnimation()), 2500);
    }
}

function runContent(index){

    content.classList.add("show");
    menu.classList.add("hide");
    setTimeout(() => {
        contentLoader(index);
    }, 5000);
        
}

async function hideContent(){

    await new Promise (resolve => {
        content.classList.remove("show");
        void content.offsetWidth;
        content.classList.add("hide");
        setTimeout(() => {
            content.classList.remove("hide");
            contentDeloader();
            resolve();
        }, 1600);
    });
   

    await new Promise(resolve => setTimeout(resolve, 2000));
    menu.classList.remove("hide");
    void menu.offsetWidth;
    menu.classList.add("show");
    setTimeout(() => {
        menu.classList.remove("show");
    }, 3100);
}

export function InitializeClick(){

    document.querySelectorAll("#list > li").forEach(item => {
        item.addEventListener("click", () => runAnimation(item.id));
    });

    elementsCount = document.getElementById("list").
    querySelectorAll("#list>li").length;
    for(var i =0; i<elementsCount; ++i)
    {
        cards.push(new Card(i));
    }
    content = document.getElementById("content");          
    menu = document.getElementById("menu");  
}

document.addEventListener("DOMContentLoaded", InitializeClick);
